
public interface Bank {
	abstract double calculateCreditScore();
}
