
public class HDFC extends RBI{

	public HDFC(String holderName, String accountNumber, double creditScore) {
		super(holderName, accountNumber, creditScore);
		// TODO Auto-generated constructor stub
	}

}
