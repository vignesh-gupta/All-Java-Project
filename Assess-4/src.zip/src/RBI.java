import java.text.DecimalFormat;


public class RBI implements Bank{
	private String accountNumber;
	private double creditScore;
	
	private String holderName;
	static double CREDIT;
	
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getCreditScore() {
		return creditScore;
	}
	public void setCreditScore(double creditScore) {
		this.creditScore = creditScore;
	}
	public String getHolderName() {
		return holderName;
	}
	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}
	
	public RBI(String holderName , String accountNumber, double creditScore) {
		// TODO Auto-generated constructor stub
		this.accountNumber=accountNumber;
		this.creditScore = creditScore;
		this.holderName = holderName;
		
	}
	
	public double calculateCreditScore() {
		double finalscore;
		finalscore = creditScore + (0.1*CREDIT);
		return finalscore;

	}
	public void display() {
		DecimalFormat df =new DecimalFormat("0.00");
		System.out.println("Hi,"+holderName);
		System.out.println("You have gained "+df.format(CREDIT/10)+" credit score for the payment of "+CREDIT);
		System.out.println("Your Total Credit Score is "+df.format(calculateCreditScore()));
	}
}
