
public class ICICI extends RBI {

	public ICICI(String holderName, String accountNumber, double creditScore) {
		super(holderName, accountNumber, creditScore);
		// TODO Auto-generated constructor stub
	}
	
	//fill your code here

}
