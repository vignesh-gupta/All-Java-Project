import java.io.*;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Select the Bank Name\n1.ICICI\n2.HDFC");
		int n = sc.nextInt();
		if(n==1||n==2)
		{
			System.out.println("Enter the Holder Name");
			String name = br.readLine();
			System.out.println("Enter the Account Number");
			String accountNumber = br.readLine();
			System.out.println("Enter the Previous Credit Score");
			double preScore = sc.nextDouble();
			System.out.println("Enter the Amount to be Paid");
			RBI.CREDIT=sc.nextDouble();
			
			RBI r = new RBI(name,accountNumber,preScore);
			r.calculateCreditScore();
			r.display();
			sc.close();
		}
		else{
			System.out.println("Invalid Bank type");
		}
	}

}
